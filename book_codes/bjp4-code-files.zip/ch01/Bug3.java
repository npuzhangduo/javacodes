public class Bug3 {
    public static void main(String[] args) {
        System.out.println("Hello, world!);
    }
}
