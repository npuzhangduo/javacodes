public class MissingSemicolon {
    public static void main(String[] args) {
        System.out.println("A rose by any other name")
        System.out.println("would smell as sweet");
    }
}
