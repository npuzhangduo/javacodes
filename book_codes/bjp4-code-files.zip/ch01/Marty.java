public class Marty {
    public static void main(String[] args) {
        System.out.println("Stuart is great\rMarty ");
    }
}
