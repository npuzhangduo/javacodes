public class Bug6 {
    public static void main(String[] ) {
        System.out.println("Hello, world!");
    }
}
