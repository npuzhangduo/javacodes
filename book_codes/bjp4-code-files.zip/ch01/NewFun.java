public class NewFun {
    public static void main(String[] args) {
        System.out.println("This is a program");
        System.out.println("with four statements.");
        System.out.println("Each terminated");
        System.out.println("by a semicolon.");
    }
}
