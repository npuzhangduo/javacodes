// A general interface for shape classes.
public interface Shape {
    public double getArea();
    public double getPerimeter();
}
