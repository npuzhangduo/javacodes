// A Point object represents a pair of (x, y) coordinates.
// First version: state only.

public class Point {
    int x;
    int y;
}
