public class DrawTriangles {

    public static void drawTriangle() {
        System.out.println("  *");
        System.out.println(" ***");
        System.out.println("*****");
        System.out.println();
    }

    public static void drawTwoTriangles() {
        drawTriangle();
        drawTriangle();
    }
}
