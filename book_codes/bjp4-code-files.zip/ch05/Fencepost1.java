public  class Fencepost1 {
    public static void main(String[] args) {
        System.out.print(1);
        for (int i = 2; i <= 10; i++) {
            System.out.print(", " + i);
        }
        System.out.println();
    }
}
